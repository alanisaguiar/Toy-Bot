defmodule ToyRobot.TableTest do
  use ExUnit.Case
  doctest ToyRobot.Table
end
