defmodule ToyRobot.CommandInterpreterTest do
  use ExUnit.Case
  doctest ToyRobot.CommandInterpreter
end
