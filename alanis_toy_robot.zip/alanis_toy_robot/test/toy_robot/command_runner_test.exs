defmodule ToyRobot.CommandRunnerTest do
  use ExUnit.Case
  doctest ToyRobot.CommandRunner
end
