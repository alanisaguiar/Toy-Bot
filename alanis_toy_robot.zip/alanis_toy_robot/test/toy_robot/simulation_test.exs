defmodule ToyRobot.SimulationTest do
  use ExUnit.Case
  doctest ToyRobot.Simulation
end
