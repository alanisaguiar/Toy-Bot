defmodule ToyRobot do
  @moduledoc """
  Documentation for `ToyRobot`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> ToyRobot.hello()
      :world

  """
  def hello do
    :world
  end
end
