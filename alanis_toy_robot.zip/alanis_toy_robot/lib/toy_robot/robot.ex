defmodule ToyRobot.Robot do
  alias ToyRobot.Robot
  defstruct [ x: 0, y: 0, facing: :north ]

#   defp validate_position(%Robot{x: x, y: y} = robot) do
#   if x in 0..4 and y in 0..4 do
#     robot
#   else
#     # Ignora o movimento
#     robot
#   end
# end

  @doc """
    Função responsável pela movimentção do robô

    ## Examples

    iex> alias ToyRobot.Robot
    ToyRobot.Robot
    iex> Robot.move(%Robot{x: 1, facing: :east})
    %Robot{x: 2, facing: :east}

    iex> alias ToyRobot.Robot
    ToyRobot.Robot
    iex> Robot.move(%Robot{x: 1, facing: :west})
    %Robot{x: 0, facing: :west}

  """
  def move(%Robot{facing: facing} = robot) do
    case facing do
      :east -> move_right(robot)
      :west -> move_left(robot)
      :north -> move_north(robot)
      :south -> move_south(robot)
    end
  end

  defp move_north(%Robot{} = robot) do
    %Robot{ robot | y: robot.y + 1 , facing: robot.facing}
  end
   defp move_south(%Robot{} = robot) do
    %Robot{ robot | y: robot.y - 1, facing: robot.facing }
  end

  defp move_right(%Robot{} = robot) do
    %Robot{ robot | x: robot.x + 1, facing: robot.facing}
  end

  defp move_left(%Robot{} = robot) do
    %Robot{ x: robot.x - 1, facing: robot.facing }
  end

  # defp move_top

  # defp move_bottom

  # def turn_left

  # def turn_right

  @doc """
  Gira o robô no sentido horário (direita)

  ## Exemplo
    iex> alias ToyRobot.Robot
    ToyRobot.Robot
    iex> robot = %Robot{x: 0, y: 0, facing: :north}
    %Robot{x: 0, y: 0, facing: :north}
    iex> robot |> Robot.turn_right
    %Robot{x: 0, y: 0, facing: :east}
  """
   def turn_right(%Robot{facing: facing} = robot) do
    case facing do
      :north -> %Robot{robot | facing: :east}
      :south -> %Robot{robot | facing: :west}
      :east -> %Robot{robot | facing: :south}
      :west -> %Robot{robot | facing: :north}
    end
  end

    @doc """
  Gira o robô no sentido anti-horário (esquerda)

  ## Exemplo
    iex> alias ToyRobot.Robot
    ToyRobot.Robot
    iex> robot = %Robot{x: 0, y: 0, facing: :north}
    %Robot{x: 0, y: 0, facing: :north}
    iex> robot |> Robot.turn_left
    %Robot{x: 0, y: 0, facing: :west}
  """

     def turn_left(%Robot{facing: facing} = robot) do
    case facing do
      :north -> %Robot{robot | facing: :west }
      :south -> %Robot{robot | facing: :east}
      :east -> %Robot{robot | facing: :north}
      :west -> %Robot{robot | facing: :south}
    end
  end

end
